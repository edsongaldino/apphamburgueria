package com.example.apphamburgueriadelivery;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName, editTextQuantity;
    private CheckBox checkBoxBacon, checkBoxCheese, checkBoxSauce;
    private TextView textViewSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        checkBoxBacon = findViewById(R.id.checkBoxBacon);
        checkBoxCheese = findViewById(R.id.checkBoxCheese);
        checkBoxSauce = findViewById(R.id.checkBoxSauce);
        textViewSummary = findViewById(R.id.textViewSummary);
    }

    public void submitOrder(View view) {
        String name = editTextName.getText().toString();
        String bacon = checkBoxBacon.isChecked() ? "Bacon" : "";
        String cheese = checkBoxCheese.isChecked() ? "Queijo" : "";
        String sauce = checkBoxSauce.isChecked() ? "Molho" : "";
        String quantity = editTextQuantity.getText().toString();

        String summary = "Pedido de " + quantity + " lanche(s) para " + name +
                ". Adicionais: " + bacon + " " + cheese + " " + sauce;

        textViewSummary.setText(summary);
    }
}